/*
 * Copyright 2004,2006 The Poderosa Project.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 *
 * $Id: TerminalParameterSerialize.cs,v 1.3 2010/12/10 22:29:02 kzmi Exp $
 */
using System;
using System.Collections.Generic;
using System.Text;
using System.Diagnostics;

using Granados;
#if UNITTEST
using System.IO;
using NUnit.Framework;
#endif

using Poderosa.Serializing;

namespace Poderosa.Protocols
{
    internal abstract class TerminalParameterSerializer : ISerializeServiceElement {

        private Type _concreteType;

        public TerminalParameterSerializer(Type concreteType) {
            _concreteType = concreteType;
        }

        public void Serialize(TerminalParameter tp, StructuredText node) {
            if(tp.TerminalType!=TerminalParameter.DEFAULT_TERMINAL_TYPE) node.Set("terminal-type", tp.TerminalType);
        }
        public void Deserialize(TerminalParameter tp, StructuredText node) {
            tp.SetTerminalName(node.Get("terminal-type", TerminalParameter.DEFAULT_TERMINAL_TYPE));
        }

        public Type ConcreteType {
            get {
                return _concreteType;
            }
        }

        public abstract StructuredText Serialize(object obj);
        public abstract object Deserialize(StructuredText node);
    }

    internal abstract class TCPParameterSerializer : TerminalParameterSerializer {
        private int _defaultPort;

        public TCPParameterSerializer(Type concreteType, int defaultport) : base(concreteType) {
            _defaultPort = defaultport;
        }


        public void Serialize(TCPParameter tp, StructuredText node) {
            base.Serialize(tp, node);
            node.Set("destination", tp.Destination);
            if(tp.Port!=_defaultPort) node.Set("port", tp.Port.ToString());
        }
        public void Deserialize(TCPParameter tp, StructuredText node) {
            base.Deserialize(tp, node);
            tp.Destination = node.Get("destination", "");
            Debug.Assert(tp.Destination!=null);
            tp.Port = ParseUtil.ParseInt(node.Get("port"), _defaultPort);
        }
    }

    internal class TelnetParameterSerializer : TCPParameterSerializer {

        public TelnetParameterSerializer() : base(typeof(TelnetParameter), 23) {
        }

        public override StructuredText Serialize(object obj) {
            StructuredText t = new StructuredText(this.ConcreteType.FullName);
            base.Serialize((TCPParameter)obj, t);
            return t;
        }

        public override object Deserialize(StructuredText node) {
            TelnetParameter t = new TelnetParameter();
            base.Deserialize(t, node);
            return t;
        }
    }

    internal class SSHParameterSerializer : TCPParameterSerializer {
        public SSHParameterSerializer() : base(typeof(SSHLoginParameter), 22) {
        }
        //�h���N���X����̎w��p
        protected SSHParameterSerializer(Type t)
            : base(t, 22) {
        }

        public void Serialize(SSHLoginParameter tp, StructuredText node) {
            base.Serialize(tp, node);
            if(tp.Method!=SSHProtocol.SSH2) node.Set("method", tp.Method.ToString());
            if(tp.AuthenticationType!=AuthenticationType.Password) node.Set("authentication", tp.AuthenticationType.ToString());
            node.Set("account", tp.Account);
            if(tp.IdentityFileName.Length>0) node.Set("identityFileName", tp.IdentityFileName);
            if(tp.PasswordOrPassphrase != null) {
                if (ProtocolsPlugin.Instance.ProtocolOptions.SavePlainTextPassword) {
                    node.Set("passphrase", tp.PasswordOrPassphrase);
                }
                else if (ProtocolsPlugin.Instance.ProtocolOptions.SavePassword) {
                    string pw = new SimpleStringEncypt().EncryptString(tp.PasswordOrPassphrase);
                    if (pw != null) {
                        node.Set("password", pw);
                    }
                }
            }
        }
        public void Deserialize(SSHLoginParameter tp, StructuredText node) {
            base.Deserialize(tp, node);
            tp.Method = "SSH1".Equals(node.Get("method"))? SSHProtocol.SSH1 : SSHProtocol.SSH2;
            tp.AuthenticationType = ParseUtil.ParseEnum<AuthenticationType>(node.Get("authentication", ""), AuthenticationType.Password);
            tp.Account = node.Get("account", "");
            tp.IdentityFileName = node.Get("identityFileName", "");
            if(ProtocolsPlugin.Instance.ProtocolOptions.ReadSerializedPassword) {
                string pw = node.Get("passphrase", null);
                if (pw != null) {
                    tp.PasswordOrPassphrase = pw;
                    tp.LetUserInputPassword = false;
                }
                else {
                    pw = node.Get("password", null);
                    if (pw != null) {
                        pw = new SimpleStringEncypt().DecryptString(pw);
                        if (pw != null) {
                            tp.PasswordOrPassphrase = pw;
                            tp.LetUserInputPassword = false;
                        }
                    }
                }
            }
        }

        public override StructuredText Serialize(object obj) {
            StructuredText t = new StructuredText(this.ConcreteType.FullName);
            Serialize((SSHLoginParameter)obj, t);
            return t;
        }

        public override object Deserialize(StructuredText node) {
            SSHLoginParameter t = new SSHLoginParameter();
            Deserialize(t, node);
            return t;
        }
    }

    internal class SSHSubsystemParameterSerializer : SSHParameterSerializer {
        public SSHSubsystemParameterSerializer() : base(typeof(SSHSubsystemParameter)) {
        }

        public void Serialize(SSHSubsystemParameter tp, StructuredText node) {
            base.Serialize(tp, node);
            node.Set("subsystemName", tp.SubsystemName);
        }
        public void Deserialize(SSHSubsystemParameter tp, StructuredText node) {
            base.Deserialize(tp, node);
            tp.SubsystemName = node.Get("subsystemName", "");
        }

        public override StructuredText Serialize(object obj) {
            StructuredText t = new StructuredText(this.ConcreteType.FullName);
            Serialize((SSHSubsystemParameter)obj, t);
            return t;
        }

        public override object Deserialize(StructuredText node) {
            SSHSubsystemParameter t = new SSHSubsystemParameter();
            Deserialize(t, node);
            return t;
        }
    }

    internal class LocalShellParameterSerializer : TerminalParameterSerializer {
        public LocalShellParameterSerializer()
            : base(typeof(LocalShellParameter)) {
        }

        public void Serialize(LocalShellParameter tp, StructuredText node) {
            base.Serialize(tp, node);
            if(CygwinUtil.DefaultHome!=tp.Home) node.Set("home", tp.Home);
            if(CygwinUtil.DefaultShell!=tp.ShellName) node.Set("shellName", tp.ShellName);
            if(CygwinUtil.DefaultCygwinDir!=tp.CygwinDir) node.Set("cygwin-directory", tp.CygwinDir);
        }
        public void Deserialize(LocalShellParameter tp, StructuredText node) {
            base.Deserialize(tp, node);
            tp.Home = node.Get("home", CygwinUtil.DefaultHome);
            tp.ShellName = node.Get("shellName", CygwinUtil.DefaultShell);
            tp.CygwinDir = node.Get("cygwin-directory", CygwinUtil.DefaultCygwinDir);
        }
        public override StructuredText Serialize(object obj) {
            StructuredText t = new StructuredText(this.ConcreteType.FullName);
            Serialize((LocalShellParameter)obj, t);
            return t;
        }

        public override object Deserialize(StructuredText node) {
            LocalShellParameter t = new LocalShellParameter();
            Deserialize(t, node);
            return t;
        }
    }

    //TODO �V���A���|�[�g

#if UNITTEST
    [TestFixture]
    public class TerminalParameterTests {

        private TelnetParameterSerializer _telnetSerializer;
        private SSHParameterSerializer _sshSerializer;
        private LocalShellParameterSerializer _localShellSerializer;

        [TestFixtureSetUp]
        public void Init() {
            _telnetSerializer = new TelnetParameterSerializer();
            _sshSerializer = new SSHParameterSerializer();
            _localShellSerializer = new LocalShellParameterSerializer();
        }

        [Test]
        public void Telnet0() {
            TelnetParameter p1 = new TelnetParameter();
            StructuredText t = _telnetSerializer.Serialize(p1);
            Assert.IsNull(t.Parent);
            Assert.IsNull(t.Get("port"));
            TelnetParameter p2 = (TelnetParameter)_telnetSerializer.Deserialize(t);
            Assert.AreEqual(23, p2.Port);
            Assert.AreEqual(TerminalParameter.DEFAULT_TERMINAL_TYPE, p2.TerminalType);
        }
        [Test]
        public void Telnet1() {
            TelnetParameter p1 = new TelnetParameter();
            p1.SetTerminalName("TERMINAL");
            p1.Port = 80;
            p1.Destination = "DESTINATION";
            StructuredText t = _telnetSerializer.Serialize(p1);
            TelnetParameter p2 = (TelnetParameter)_telnetSerializer.Deserialize(t);
            Assert.AreEqual(80, p2.Port);
            Assert.AreEqual("TERMINAL", p2.TerminalType);
            Assert.AreEqual("DESTINATION", p2.Destination);
        }
        [Test]
        public void SSH0() {
            SSHLoginParameter p1 = new SSHLoginParameter();
            StructuredText t = _sshSerializer.Serialize(p1);
            //�m�F
            StringWriter wr = new StringWriter();
            new TextStructuredTextWriter(wr).Write(t);
            wr.Close();
            Debug.WriteLine(wr.ToString());

            Assert.IsNull(t.Get("port"));
            Assert.IsNull(t.Get("method"));
            Assert.IsNull(t.Get("authentication"));
            Assert.IsNull(t.Get("identityFileName"));
            SSHLoginParameter p2 = (SSHLoginParameter)_sshSerializer.Deserialize(t);
            Assert.AreEqual(22, p2.Port);
            Assert.AreEqual(SSHProtocol.SSH2, p2.Method);
            Assert.AreEqual(AuthenticationType.Password, p2.AuthenticationType);
            Assert.AreEqual("", p2.IdentityFileName);
        }
        [Test]
        public void SSH1() {
            SSHLoginParameter p1 = new SSHLoginParameter();
            p1.Method = SSHProtocol.SSH1;
            p1.Account = "account";
            p1.IdentityFileName = "identity-file";
            p1.AuthenticationType = AuthenticationType.PublicKey;
            
            StructuredText t = _sshSerializer.Serialize(p1);
            UnitTestUtil.DumpStructuredText(t);
            //�m�F
            Debug.WriteLine(UnitTestUtil.DumpStructuredText(t));

            SSHLoginParameter p2 = (SSHLoginParameter)_sshSerializer.Deserialize(t);
            Assert.AreEqual(SSHProtocol.SSH1, p2.Method);
            Assert.AreEqual(AuthenticationType.PublicKey, p2.AuthenticationType);
            Assert.AreEqual("identity-file", p2.IdentityFileName);
            Assert.AreEqual("account", p2.Account);
        }
        //TODO CYGWIN
        //TODO StructuredText����ō쐬���A�{�����肦�Ȃ��f�[�^�������Ă��Ă������Ɠǂ߂邱�Ƃ��e�X�g
    }
#endif
}
