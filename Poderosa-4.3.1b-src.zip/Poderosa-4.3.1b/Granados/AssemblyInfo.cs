/*
 Copyright (c) 2005 Poderosa Project, All Rights Reserved.
 This file is a part of the Granados SSH Client Library that is subject to
 the license included in the distributed package.
 You may not use this file except in compliance with the license.

* $Id: AssemblyInfo.cs,v 1.5 2010/11/19 15:40:39 kzmi Exp $
*/
using System.Reflection;
using System.Runtime.CompilerServices;

[assembly: AssemblyTitle("Granados")]
[assembly: AssemblyDescription("SSH Client Library")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyProduct("")]
[assembly: AssemblyCopyright("")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]		


[assembly: AssemblyVersion("2.0.0")]

[assembly: AssemblyDelaySign(false)]
