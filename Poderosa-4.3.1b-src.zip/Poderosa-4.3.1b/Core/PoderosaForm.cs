/*
 * Copyright 2004,2006 The Poderosa Project.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 *
 * $Id: PoderosaForm.cs,v 1.1 2010/12/18 09:40:56 kzmi Exp $
 */
using System;
using System.Collections;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

using Poderosa.Commands;
using Poderosa.View;
using Poderosa.Util.Collections;

namespace Poderosa.Forms
{
    //���C���E�B���h�E�ƃ|�b�v�A�b�v�E�B���h�E�̊��
#if UIDESIGN
    internal class PoderosaForm : Form, IPoderosaForm {
#else
    internal abstract class PoderosaForm : Form, IPoderosaForm {
#endif
        protected KeyboardHandlerManager _commandKeyHandler;

        private delegate DialogResult MessageBoxInternalDelegate(string msg, MessageBoxButtons buttons, MessageBoxIcon icon);
        private MessageBoxInternalDelegate _messageBoxInternalDelegate;

        public PoderosaForm() {
            _messageBoxInternalDelegate = new MessageBoxInternalDelegate(this.MessageBoxInternal);

            IPoderosaAboutBoxFactory aboutBoxFactory = AboutBoxUtil.GetCurrentAboutBoxFactory();
            if (aboutBoxFactory != null)
                this.Icon = aboutBoxFactory.ApplicationIcon;

            //�V���[�g�J�b�g�L�[�͋���
            _commandKeyHandler = new KeyboardHandlerManager();
            _commandKeyHandler.AddLastHandler(new CommandShortcutKeyHandler(this));
        }

        public Form AsForm() {
            return this;
        }

        public Control AsControl() {
            return this;
        }

        //�R���e�L�X�g���j���[�\��
        public void ShowContextMenu(IPoderosaMenuGroup[] menus, ICommandTarget target, Point point_screen, ContextMenuFlags flags) {
            //�܂��\�[�g
            ICollection sorted = PositionDesignationSorter.SortItems(menus);
            ContextMenuStrip cm = new ContextMenuStrip();
            MenuUtil.BuildContextMenu(cm, new ConvertingEnumerable<IPoderosaMenuGroup>(sorted), target);
            if(cm.Items.Count==0) return;

            //�L�[�{�[�h������g���K�Ƀ��j���[���o���Ƃ��́A�I�����������ق��������Ƒ��삵�₷���B
            if((flags & ContextMenuFlags.SelectFirstItem)!=ContextMenuFlags.None)
                cm.Items[0].Select();

            try {
                cm.Show(this, this.PointToClient(point_screen));
            }
            catch(Exception ex) {
                RuntimeUtil.ReportException(ex);
            }
        }

        void IPoderosaForm.Warning(string msg) {
            MessageBoxInternal(msg, MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }
        void IPoderosaForm.Information(string msg) {
            MessageBoxInternal(msg, MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
        DialogResult IPoderosaForm.AskUserYesNo(string msg) {
            return MessageBoxInternal(msg, MessageBoxButtons.YesNo, MessageBoxIcon.Question);
        }
        private DialogResult MessageBoxInternal(string msg, MessageBoxButtons buttons, MessageBoxIcon icon) {
            if(this.InvokeRequired) {
                return (DialogResult)this.Invoke(_messageBoxInternalDelegate, new object[] { msg, buttons, icon });
            }
            else
                return MessageBox.Show(msg, "Poderosa", buttons, icon);
        }

        protected override bool ProcessCmdKey(ref Message msg, Keys keyData) {
            //Debug.WriteLine("ProcessCmdKey " + keyData.ToString());
            if(base.ProcessCmdKey(ref msg, keyData))
                return true;
            else if(_commandKeyHandler.Process(keyData)==UIHandleResult.Stop)
                return true;
            else
                return false;
        }

        protected bool _closeCancelled;
        public CommandResult CancellableClose() {
            _closeCancelled = false;
            this.Close(); //�L�����Z�������Ƃ���OnClosing���ŏ�̃t���O���Z�b�g����
            return _closeCancelled? CommandResult.Cancelled : CommandResult.Succeeded;
        }

        #region IAdaptable
        public IAdaptable GetAdapter(Type adapter) {
            return WindowManagerPlugin.Instance.PoderosaWorld.AdapterManager.GetAdapter(this, adapter);
        }
        #endregion
    }
}
