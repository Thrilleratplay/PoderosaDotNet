/*
 * Copyright 2004,2006 The Poderosa Project.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 *
 * $Id: MacroExec.cs,v 1.4 2010/12/16 15:33:14 kzmi Exp $
 */
using System;
using System.Threading;
using System.Text;
using System.Reflection;
using System.Diagnostics;
using System.Windows.Forms;
using System.Collections.Generic;
using System.CodeDom.Compiler;
using System.Globalization;
using System.Drawing;
using System.IO;
using System.Collections.Specialized;
using Microsoft.JScript;

using Poderosa.Plugins;
using Poderosa.ConnectionParam;
using Poderosa.Terminal;
using Poderosa.Sessions;
using Poderosa.Protocols;
using Poderosa.Commands;
using Poderosa.View;

using MacroEnvironment = Poderosa.Macro.Environment;

namespace Poderosa.MacroInternal
{
	internal class MacroUtil
	{
		public static Assembly LoadMacroAssembly(MacroModule mod) {
			if(mod.Type==MacroType.Assembly) {
				return Assembly.LoadFrom(mod.Path);
			}
			else if(mod.Type==MacroType.JavaScript) {
                JScriptCodeProvider compiler = new JScriptCodeProvider();
				CompilerParameters param = new CompilerParameters();
				param.IncludeDebugInformation = true;
				param.GenerateInMemory = false; //���ꂪ�v���O�C�������[�h�ł��邩�ǂ����̌��ߎ�ɂȂ����B���ӂ����ׂė��������킯�ł͂Ȃ����A�Ƃ肠��������ł悵�Ƃ���B�[���肵�Ă��鎞�Ԃ͂��܂�Ȃ���
				param.GenerateExecutable = true;

				StringCollection sc = param.ReferencedAssemblies;

#if MONOLITHIC
                string root = MacroPlugin.Instance.PoderosaApplication.HomeDirectory;
				param.ReferencedAssemblies.Add("System.Drawing.dll");
				param.ReferencedAssemblies.Add("System.Windows.Forms.dll");
				sc.Add(root + "Poderosa.Monolithic.exe");
#else
				bool[] assyAdded = new bool[9];
				foreach (Assembly assy in AppDomain.CurrentDomain.GetAssemblies()) {
					try {
						string assyFilePath = new Uri(assy.CodeBase).LocalPath;
						if (Path.GetExtension(assyFilePath).ToLower(CultureInfo.InvariantCulture) == ".dll") {
							string assyFileName = Path.GetFileNameWithoutExtension(assyFilePath).ToLower(CultureInfo.InvariantCulture);
							switch (assyFileName) {
								case "system.drawing":
									assyAdded[0] = true;
									break;
								case "system.windows.forms":
									assyAdded[1] = true;
									break;
								case "poderosa.plugin":
									assyAdded[2] = true;
									break;
								case "poderosa.core":
									assyAdded[3] = true;
									break;
								case "granados":
									assyAdded[4] = true;
									break;
								case "poderosa.protocols":
									assyAdded[5] = true;
									break;
								case "poderosa.terminalemulator":
									assyAdded[6] = true;
									break;
								case "poderosa.terminalsession":
									assyAdded[7] = true;
									break;
								case "poderosa.macro":
									assyAdded[8] = true;
									break;
								default:
									continue;
							}
							Debug.WriteLine("(LoadMacroAssembly) add to ReferencedAssemblies: " + assyFilePath);
							sc.Add(assyFilePath);
						}
					}
					catch (Exception) {
					}
				}
				foreach(bool flag in assyAdded) {
					if (!flag) {
						throw new Exception(MacroPlugin.Instance.Strings.GetString("Message.MacroExec.MissingAssemblies"));
					}
				}
#endif
				foreach(string x in mod.AdditionalAssemblies)
					if(x.Length>0) sc.Add(x);

				CompilerResults result = compiler.CompileAssemblyFromFile(param, mod.Path);
				if(result.Errors.Count>0) {
					StringBuilder bld = new StringBuilder();
					bld.Append(MacroPlugin.Instance.Strings.GetString("Message.MacroExec.FailedToCompileScript"));
					foreach(CompilerError err in result.Errors) {
						bld.Append(String.Format("Line {0} Column {1} : {2}\n", err.Line, err.Column, err.ErrorText));
					}
					throw new Exception(bld.ToString());
				}

                Debug.WriteLineIf(DebugOpt.Macro, "Compiled:"+result.PathToAssembly+" FullName:"+result.CompiledAssembly.FullName);
                //AppDomain.CurrentDomain.Load(result.CompiledAssembly.FullName, result.Evidence);

				return result.CompiledAssembly;
			}
			else
				throw new Exception("Unsupported macro module type " + mod.Type.ToString() + " is specified.");
		}
		private static string GetMacroPath() {
			string t = typeof(MacroUtil).Assembly.CodeBase;
			int c1 = t.IndexOf(':'); //�擪��file://...�Ƃ���
			int c2 = t.IndexOf(':', c1+1); //���ꂪ�h���C�u������̃R����
			t = t.Substring(c2-1);
			return t.Replace('/', '\\');
		}
		private static string GetCorePath() {
			string t = typeof(Poderosa.View.RenderProfile).Assembly.CodeBase;
			int c1 = t.IndexOf(':'); //�擪��file://...�Ƃ���
			int c2 = t.IndexOf(':', c1+1); //���ꂪ�h���C�u������̃R����
			t = t.Substring(c2-1);
			return t.Replace('/', '\\');
		}

        //Invoke�n
        public static void InvokeMessageBox(string msg) {
            Form f = MacroPlugin.Instance.WindowManager.ActiveWindow.AsForm();
            f.Invoke(new MessageBoxDelegate(GUtil.Warning), f, msg);
        }
        public static ITerminalSession InvokeOpenSessionOrNull(ICommandTarget target, TerminalParam param) {
            ITerminalParameter tp = param.ConvertToTerminalParameter();
            ITerminalSettings ts = CreateTerminalSettings(param);
            
            IViewManager pm = CommandTargetUtil.AsWindow(target).ViewManager;
            //�Ɨ��E�B���h�E�Ƀ|�b�v�A�b�v������悤�Ȃ��Ƃ͍l���Ă��Ȃ�
            IContentReplaceableView rv = (IContentReplaceableView)pm.GetCandidateViewForNewDocument().GetAdapter(typeof(IContentReplaceableView));
            TerminalControl tc = (TerminalControl)rv.GetCurrentContent().GetAdapter(typeof(TerminalControl));
            if(tc!=null) { //�^�[�~�i���R���g���[�����Ȃ��Ƃ��͖����ɐݒ肵�ɂ����Ȃ�
                RenderProfile rp = ts.UsingDefaultRenderProfile? MacroPlugin.Instance.TerminalEmulatorService.TerminalEmulatorOptions.CreateRenderProfile() : ts.RenderProfile;
                Size sz = tc.CalcTerminalSize(rp);
                tp.SetTerminalSize(sz.Width, sz.Height);
            }


            return (ITerminalSession)MacroPlugin.Instance.WindowManager.ActiveWindow.AsForm().Invoke(new OpenSessionDelegate(OpenSessionOrNull), tp, ts);
        }
        private static ITerminalSession OpenSessionOrNull(ITerminalParameter tp, ITerminalSettings ts) {
            try {
                ITerminalSessionsService ss = MacroPlugin.Instance.TerminalSessionsService;
                ITerminalSession newsession = ss.TerminalSessionStartCommand.StartTerminalSession(MacroPlugin.Instance.WindowManager.ActiveWindow, tp, ts);
                if(newsession==null) return null;

                MacroPlugin.Instance.MacroManager.CurrentExecutor.AddRuntimeSession(newsession);
                return newsession;
            }
            catch(Exception ex) {
                RuntimeUtil.ReportException(ex);
                return null;
            }
        }
        private static ITerminalSettings CreateTerminalSettings(TerminalParam param) {
            ITerminalSettings ts = MacroPlugin.Instance.TerminalEmulatorService.CreateDefaultTerminalSettings(param.Caption, null);
            ts.BeginUpdate();
            ts.RenderProfile = param.RenderProfile;
            ts.TransmitNL = param.TransmitNL;
            ts.LocalEcho = param.LocalEcho;
            ts.Encoding = param.Encoding;
            if(param.LogType!=LogType.None)
                ts.LogSettings.Add(CreateSimpleLogSettings(param));
            ts.EndUpdate();
            return ts;
        }
        private static ISimpleLogSettings CreateSimpleLogSettings(TerminalParam param) {
            ISimpleLogSettings logsettings = MacroPlugin.Instance.TerminalEmulatorService.CreateDefaultSimpleLogSettings();
            logsettings.LogPath = param.LogPath;
            logsettings.LogType = param.LogType;
            logsettings.LogAppend = param.LogAppend;
            return logsettings;
        }

        public static void InvokeActivate(IPoderosaDocument document) {
            MacroPlugin.Instance.WindowManager.ActiveWindow.AsForm().Invoke(new DocDelegate(ActivateDoc), document);
        }
        private static void ActivateDoc(IPoderosaDocument document) {
            MacroPlugin.Instance.SessionManager.ActivateDocument(document, ActivateReason.InternalAction);
        }
        public static void InvokeClose(IPoderosaDocument document) {
            MacroPlugin.Instance.WindowManager.ActiveWindow.AsForm().Invoke(new DocDelegate(CloseDoc), document);
        }
        private static void CloseDoc(IPoderosaDocument document) {
            MacroPlugin.Instance.SessionManager.CloseDocument(document);
        }


        private delegate void MessageBoxDelegate(IWin32Window window, string msg);
        private delegate ITerminalSession OpenSessionDelegate(ITerminalParameter tp, ITerminalSettings ts);
        private delegate void DocDelegate(IPoderosaDocument document);
	}
	internal class MacroExecutor {
		
		private MacroModule _module;
		private Assembly _assembly;
		private MacroTraceWindow _traceWindow;
		private Thread _macroThread;
        private List<ReceptionDataPool> _receptionDataPool;

		public MacroExecutor(MacroModule mod, Assembly asm) {
			_module = mod;
            _assembly = asm;
            _receptionDataPool = new List<ReceptionDataPool>();
			if(mod.DebugMode) {
				_traceWindow = new MacroTraceWindow();
				_traceWindow.AdjustTitle(mod);
				_traceWindow.Owner = MacroPlugin.Instance.WindowManager.ActiveWindow.AsForm();
				_traceWindow.Show();
			}
		}
		public MacroModule Module {
			get {
				return _module;
			}
		}


		public void AsyncExec() {
            InitReceptionPool();
			_macroThread = new Thread(new ThreadStart(MacroMain));
			_macroThread.Start();
		}

		private void MacroMain() {
			try {
				InitEnv();
                //AppDomain.CurrentDomain.Load(_assembly.FullName);
                MethodInfo mi = _assembly.EntryPoint;
                if(DebugOpt.Macro) {
                    Type[] ts = _assembly.GetTypes();
                    foreach(Type t in ts) {
                        Debug.WriteLine("Found Type " + t.FullName);

                        mi = _assembly.GetType("JScript Main").GetMethod("Main");
                        Debug.WriteLine("Method Found " + mi.Name);
                    }

                }

                if(mi==null)
                    MacroUtil.InvokeMessageBox(MacroPlugin.Instance.Strings.GetString("Message.MacroModule.NoEntryPoint"));
                else
                    mi.Invoke(null, BindingFlags.InvokeMethod, null, new object[1] { new string[0] }, CultureInfo.CurrentUICulture);
			}
			catch(TargetInvocationException tex) {
				Exception inner = tex.InnerException;
				if(_traceWindow==null) {
					MacroUtil.InvokeMessageBox(String.Format(MacroPlugin.Instance.Strings.GetString("Message.MacroExec.ExceptionWithoutTraceWindow"), inner.Message));
					Debug.WriteLine("TargetInvocationException");
					Debug.WriteLine(inner.GetType().Name);
					Debug.WriteLine(inner.Message);
					Debug.WriteLine(inner.StackTrace);
				}
				else {
					_traceWindow.AddLine(MacroPlugin.Instance.Strings.GetString("Message.MacroExec.ExceptionInMacro"));
					_traceWindow.AddLine(String.Format("{0} : {1}", inner.GetType().FullName, inner.Message));
					_traceWindow.AddLine(inner.StackTrace);
				}
			}
			catch(Exception ex) {
				Debug.WriteLine(ex.Message);
				Debug.WriteLine(ex.StackTrace);
			}
			finally {
                MacroPlugin.Instance.MacroManager.IndicateMacroFinished();
                CloseAll();
			}
		}
		private void InitEnv() {
			MacroEnvironment.Init(new ConnectionListImpl(), new UtilImpl(), new DebugServiceImpl(_traceWindow));
		}

		public void Abort() {
			_macroThread.Abort();
		}

        //���s����Z�b�V�����Ƀ^�X�N�o�^�B�}�N�����s���ɓ����Ă����Z�b�V���������łȂ��A�}�N���ɂ���ĊJ�݂����Z�b�V���������l
        public void AddRuntimeSession(ITerminalSession session) {
            ReceptionDataPool pool = new ReceptionDataPool();
            _receptionDataPool.Add(pool);
            session.Terminal.StartModalTerminalTask(pool);
        }

        private void InitReceptionPool() {
            foreach(ISession session in MacroPlugin.Instance.SessionManager.AllSessions) {
                ITerminalSession ts = (ITerminalSession)session.GetAdapter(typeof(ITerminalSession));
                if(ts!=null) AddRuntimeSession(ts);
            }
        }
        private void CloseAll() {
            foreach(ReceptionDataPool pool in _receptionDataPool)
                pool.Close();
        }
	}

    //��M�f�[�^�����߂Ă���
    internal class ReceptionDataPool : IModalCharacterTask {
        private IModalTerminalTaskSite _site;
        private StringBuilder _bufferForMacro;
        private AutoResetEvent _signalForMacro;

        public void InitializeModelTerminalTask(IModalTerminalTaskSite site, IByteAsyncInputStream default_handler, ITerminalConnection connection) {
            _site = site;
            _bufferForMacro = new StringBuilder();
            _signalForMacro = new AutoResetEvent(false);
        }

        public string Caption {
            get {
                return "MACRO";
            }
        }

        public bool ShowInputInTerminal {
            get {
                return true;
            }
        }

        public IAdaptable GetAdapter(Type adapter) {
            return MacroPlugin.Instance.PoderosaWorld.AdapterManager.GetAdapter(this, adapter);
        }

        public void OnReception(ByteDataFragment data) {
        }

        public void OnNormalTermination() {
            _site.Cancel(null);
        }

        public void OnAbnormalTermination(string message) {
            _site.Cancel(null);
        }

        public void NotifyEndOfPacket() {
            _signalForMacro.Set();
        }

        public void Close() {
            _site.Complete();
            _signalForMacro.Close();
        }

        //�}�N�����s�X���b�h����Ă΂��P�s�ǂݏo�����\�b�h
        public string ReadLineFromMacroBuffer() {
            do {
                int l = _bufferForMacro.Length;
                int i=0;
                for(i=0; i<l; i++) {
                    if(_bufferForMacro[i]=='\n') break;
                }

                if(l>0 && i<l) { //�߂ł����s�����݂�����
                    int j=i;
                    if(i>0 && _bufferForMacro[i-1]=='\r') j=i-1; //CRLF�̂Ƃ��͏����Ă��
                    string r;
                    lock(_bufferForMacro) {
                        r = _bufferForMacro.ToString(0, j);
                        _bufferForMacro.Remove(0, i+1);
                    }
                    return r;
                }
                else {
                    _signalForMacro.Reset();
                    _signalForMacro.WaitOne();
                }
            } while(true);
        }
        //�}�N�����s�X���b�h����Ă΂��A�u�����f�[�^������ΑS�������Ă����v���\�b�h
        public string ReadAllFromMacroBuffer() {
            if(_bufferForMacro.Length==0) {
                _signalForMacro.Reset();
                _signalForMacro.WaitOne();
            }

            lock(_bufferForMacro) {
                string r = _bufferForMacro.ToString();
                _bufferForMacro.Remove(0, _bufferForMacro.Length);
                return r;
            }
        }
        public void ProcessChar(char ch) {
            if(Char.IsControl(ch) && ch != '\n')
                return;

            lock(_bufferForMacro) {
                _bufferForMacro.Append(ch); //!!�����ɏ���������ق������S����
            }
        }

    }
}
