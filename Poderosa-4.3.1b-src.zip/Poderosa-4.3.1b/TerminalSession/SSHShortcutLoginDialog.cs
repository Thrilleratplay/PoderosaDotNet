/*
 * Copyright 2004,2006 The Poderosa Project.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 *
 * $Id: SSHShortcutLoginDialog.cs,v 1.3 2010/12/04 12:20:41 kzmi Exp $
 */
using System;
using System.Diagnostics;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.IO;

using Poderosa.Util;
using Poderosa.Terminal;
using Poderosa.ConnectionParam;
using Poderosa.Protocols;
using Poderosa.Forms;
using Poderosa.View;

using Granados;

namespace Poderosa.Sessions
{
	/// <summary>
	/// SSHShortcutLoginDialog �̊T�v�̐����ł��B
	/// </summary>
	internal class SSHShortcutLoginDialog : LoginDialogBase {

        private ISSHLoginParameter _sshParam;
		
		private TextBox _privateKeyBox;
		private TextBox _passphraseBox;
		private Button _privateKeySelect;
		private System.Windows.Forms.Label _hostLabel;
		private System.Windows.Forms.Label _hostBox;
		private System.Windows.Forms.Label _methodLabel;
		private System.Windows.Forms.Label _methodBox;
		private System.Windows.Forms.Label _accountLabel;
		private System.Windows.Forms.Label _accountBox;
		private System.Windows.Forms.Label _authenticationTypeLabel;
		private System.Windows.Forms.Label _authenticationTypeBox;
		private System.Windows.Forms.Label _encodingLabel;
		private System.Windows.Forms.Label _encodingBox;
		private ComboBox _logFileBox;
		private Button _selectlogButton;
		private System.Windows.Forms.Label _privateKeyLabel;
		private System.Windows.Forms.Label _passphraseLabel;
		private System.Windows.Forms.Label _logFileLabel;
		private ComboBox _logTypeBox;
		private System.Windows.Forms.Label _logTypeLabel;
		/// <summary>
		/// �K�v�ȃf�U�C�i�ϐ��ł��B
		/// </summary>
		private System.ComponentModel.Container components = null;

		public SSHShortcutLoginDialog(IPoderosaMainWindow parent, ISSHLoginParameter param, ITerminalSettings settings) : base(parent)
		{
            this.TerminalSettings = settings;

			//
			// Windows �t�H�[�� �f�U�C�i �T�|�[�g�ɕK�v�ł��B
			//
			InitializeComponent();

			this._privateKeyLabel.Text = TEnv.Strings.GetString("Form.SSHShortcutLoginDialog._privateKeyLabel");
			this._passphraseLabel.Text = TEnv.Strings.GetString("Form.SSHShortcutLoginDialog._passphraseLabel");
			this._logFileLabel.Text = TEnv.Strings.GetString("Form.SSHShortcutLoginDialog._logFileLabel");
			this._hostLabel.Text = TEnv.Strings.GetString("Form.SSHShortcutLoginDialog._hostLabel");
			this._methodLabel.Text = TEnv.Strings.GetString("Form.SSHShortcutLoginDialog._methodLabel");
			this._accountLabel.Text = TEnv.Strings.GetString("Form.SSHShortcutLoginDialog._accountLabel");
			this._authenticationTypeLabel.Text = TEnv.Strings.GetString("Form.SSHShortcutLoginDialog._authenticationTypeLabel");
			this._encodingLabel.Text = TEnv.Strings.GetString("Form.SSHShortcutLoginDialog._encodingLabel");
			this._logTypeLabel.Text = TEnv.Strings.GetString("Form.SSHShortcutLoginDialog._logTypeLabel");
			this.Text = TEnv.Strings.GetString("Form.SSHShortcutLoginDialog.Text");
			this._cancelButton.Text = TEnv.Strings.GetString("Common.Cancel");
			this._loginButton.Text = TEnv.Strings.GetString("Common.OK");

            this._logTypeBox.Items.AddRange(EnumDescAttribute.For(typeof(LogType)).DescriptionCollection());

			_sshParam = param;
			InitUI();
		}

		/// <summary>
		/// �g�p����Ă��郊�\�[�X�Ɍ㏈�������s���܂��B
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// �f�U�C�i �T�|�[�g�ɕK�v�ȃ��\�b�h�ł��B���̃��\�b�h�̓��e��
		/// �R�[�h �G�f�B�^�ŕύX���Ȃ��ł��������B
		/// this._logTypeBox.Items.AddRange(EnumDescAttributeT.For(typeof(LogType)).DescriptionCollection());
		/// </summary>
		private void InitializeComponent()
		{
			this._privateKeyBox = new TextBox();
			this._privateKeyLabel = new System.Windows.Forms.Label();
			this._passphraseBox = new TextBox();
			this._passphraseLabel = new System.Windows.Forms.Label();
			this._privateKeySelect = new Button();
			this._logFileBox = new ComboBox();
			this._logFileLabel = new System.Windows.Forms.Label();
			this._selectlogButton = new Button();
			this._hostLabel = new System.Windows.Forms.Label();
			this._hostBox = new System.Windows.Forms.Label();
			this._methodLabel = new System.Windows.Forms.Label();
			this._methodBox = new System.Windows.Forms.Label();
			this._accountLabel = new System.Windows.Forms.Label();
			this._accountBox = new System.Windows.Forms.Label();
			this._authenticationTypeLabel = new System.Windows.Forms.Label();
			this._authenticationTypeBox = new System.Windows.Forms.Label();
			this._encodingLabel = new System.Windows.Forms.Label();
			this._encodingBox = new System.Windows.Forms.Label();
			this._logTypeBox = new ComboBox();
			this._logTypeLabel = new System.Windows.Forms.Label();
			this.SuspendLayout();
			// 
			// _privateKeyBox
			// 
			this._privateKeyBox.Location = new System.Drawing.Point(104, 128);
			this._privateKeyBox.Name = "_privateKeyBox";
			this._privateKeyBox.Size = new System.Drawing.Size(160, 19);
			this._privateKeyBox.TabIndex = 3;
			this._privateKeyBox.Text = "";
			// 
			// _privateKeyLabel
			// 
			this._privateKeyLabel.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this._privateKeyLabel.Location = new System.Drawing.Point(8, 128);
			this._privateKeyLabel.Name = "_privateKeyLabel";
			this._privateKeyLabel.RightToLeft = System.Windows.Forms.RightToLeft.No;
			this._privateKeyLabel.Size = new System.Drawing.Size(72, 16);
			this._privateKeyLabel.TabIndex = 2;
			this._privateKeyLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// _passphraseBox
			// 
			this._passphraseBox.Location = new System.Drawing.Point(104, 104);
			this._passphraseBox.Name = "_passphraseBox";
			this._passphraseBox.PasswordChar = '*';
			this._passphraseBox.Size = new System.Drawing.Size(184, 19);
			this._passphraseBox.TabIndex = 1;
			this._passphraseBox.Text = "";
			// 
			// _passphraseLabel
			// 
			this._passphraseLabel.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this._passphraseLabel.Location = new System.Drawing.Point(8, 104);
			this._passphraseLabel.Name = "_passphraseLabel";
			this._passphraseLabel.RightToLeft = System.Windows.Forms.RightToLeft.No;
			this._passphraseLabel.Size = new System.Drawing.Size(80, 16);
			this._passphraseLabel.TabIndex = 0;
			this._passphraseLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// _privateKeySelect
			// 
			this._privateKeySelect.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this._privateKeySelect.ImageIndex = 0;
			this._privateKeySelect.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this._privateKeySelect.Location = new System.Drawing.Point(272, 128);
			this._privateKeySelect.Name = "_privateKeySelect";
			this._privateKeySelect.RightToLeft = System.Windows.Forms.RightToLeft.No;
			this._privateKeySelect.Size = new System.Drawing.Size(19, 19);
			this._privateKeySelect.TabIndex = 4;
			this._privateKeySelect.Text = "...";
			this._privateKeySelect.Click += new System.EventHandler(this.OnOpenPrivateKey);
			// 
			// _logFileBox
			// 
			this._logFileBox.Location = new System.Drawing.Point(104, 176);
			this._logFileBox.Name = "_logFileBox";
			this._logFileBox.Size = new System.Drawing.Size(160, 20);
			this._logFileBox.TabIndex = 8;
			// 
			// _logFileLabel
			// 
			this._logFileLabel.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this._logFileLabel.Location = new System.Drawing.Point(8, 176);
			this._logFileLabel.Name = "_logFileLabel";
			this._logFileLabel.RightToLeft = System.Windows.Forms.RightToLeft.No;
			this._logFileLabel.Size = new System.Drawing.Size(88, 16);
			this._logFileLabel.TabIndex = 7;
			this._logFileLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// _selectlogButton
			// 
			this._selectlogButton.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this._selectlogButton.ImageIndex = 0;
			this._selectlogButton.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this._selectlogButton.Location = new System.Drawing.Point(272, 176);
			this._selectlogButton.Name = "_selectlogButton";
			this._selectlogButton.RightToLeft = System.Windows.Forms.RightToLeft.No;
			this._selectlogButton.Size = new System.Drawing.Size(19, 19);
			this._selectlogButton.TabIndex = 9;
			this._selectlogButton.Text = "...";
			this._selectlogButton.Click += new System.EventHandler(this.SelectLog);
			// 
			// _cancelButton
			// 
			this._cancelButton.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			this._cancelButton.ImageIndex = 0;
			this._cancelButton.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this._cancelButton.Location = new System.Drawing.Point(216, 208);
			this._cancelButton.Name = "_cancelButton";
			this._cancelButton.FlatStyle = FlatStyle.System;
			this._cancelButton.RightToLeft = System.Windows.Forms.RightToLeft.No;
			this._cancelButton.Size = new System.Drawing.Size(72, 25);
			this._cancelButton.TabIndex = 11;
			// 
			// _loginButton
			// 
			this._loginButton.DialogResult = System.Windows.Forms.DialogResult.OK;
			this._loginButton.ImageIndex = 0;
			this._loginButton.FlatStyle = FlatStyle.System;
			this._loginButton.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this._loginButton.Location = new System.Drawing.Point(128, 208);
			this._loginButton.Name = "_loginButton";
			this._loginButton.RightToLeft = System.Windows.Forms.RightToLeft.No;
			this._loginButton.Size = new System.Drawing.Size(72, 25);
			this._loginButton.TabIndex = 10;
			// 
			// _hostLabel
			// 
			this._hostLabel.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this._hostLabel.Location = new System.Drawing.Point(8, 8);
			this._hostLabel.Name = "_hostLabel";
			this._hostLabel.Size = new System.Drawing.Size(80, 16);
			this._hostLabel.TabIndex = 0;
			this._hostLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// _hostBox
			// 
			this._hostBox.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this._hostBox.Location = new System.Drawing.Point(104, 8);
			this._hostBox.Name = "_hostBox";
			this._hostBox.Size = new System.Drawing.Size(144, 16);
			this._hostBox.TabIndex = 35;
			this._hostBox.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// _methodLabel
			// 
			this._methodLabel.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this._methodLabel.Location = new System.Drawing.Point(8, 24);
			this._methodLabel.Name = "_methodLabel";
			this._methodLabel.Size = new System.Drawing.Size(80, 16);
			this._methodLabel.TabIndex = 0;
			this._methodLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// _methodBox
			// 
			this._methodBox.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this._methodBox.Location = new System.Drawing.Point(104, 24);
			this._methodBox.Name = "_methodBox";
			this._methodBox.Size = new System.Drawing.Size(144, 16);
			this._methodBox.TabIndex = 0;
			this._methodBox.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// _accountLabel
			// 
			this._accountLabel.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this._accountLabel.Location = new System.Drawing.Point(8, 40);
			this._accountLabel.Name = "_accountLabel";
			this._accountLabel.Size = new System.Drawing.Size(80, 16);
			this._accountLabel.TabIndex = 0;
			this._accountLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// _accountBox
			// 
			this._accountBox.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this._accountBox.Location = new System.Drawing.Point(104, 40);
			this._accountBox.Name = "_accountBox";
			this._accountBox.Size = new System.Drawing.Size(144, 16);
			this._accountBox.TabIndex = 0;
			this._accountBox.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// _AuthenticationTypeLabel
			// 
			this._authenticationTypeLabel.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this._authenticationTypeLabel.Location = new System.Drawing.Point(8, 56);
			this._authenticationTypeLabel.Name = "_AuthenticationTypeLabel";
			this._authenticationTypeLabel.Size = new System.Drawing.Size(80, 16);
			this._authenticationTypeLabel.TabIndex = 0;
			this._authenticationTypeLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// _AuthenticationTypeBox
			// 
			this._authenticationTypeBox.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this._authenticationTypeBox.Location = new System.Drawing.Point(104, 56);
			this._authenticationTypeBox.Name = "_AuthenticationTypeBox";
			this._authenticationTypeBox.Size = new System.Drawing.Size(144, 16);
			this._authenticationTypeBox.TabIndex = 0;
			this._authenticationTypeBox.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// _encodingLabel
			// 
			this._encodingLabel.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this._encodingLabel.Location = new System.Drawing.Point(8, 72);
			this._encodingLabel.Name = "_encodingLabel";
			this._encodingLabel.Size = new System.Drawing.Size(80, 16);
			this._encodingLabel.TabIndex = 0;
			this._encodingLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// _encodingBox
			// 
			this._encodingBox.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this._encodingBox.Location = new System.Drawing.Point(104, 72);
			this._encodingBox.Name = "_encodingBox";
			this._encodingBox.Size = new System.Drawing.Size(144, 16);
			this._encodingBox.TabIndex = 0;
			this._encodingBox.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// _logTypeBox
			// 
			this._logTypeBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this._logTypeBox.Location = new System.Drawing.Point(104, 152);
			this._logTypeBox.Name = "_logTypeBox";
			this._logTypeBox.Size = new System.Drawing.Size(96, 20);
			this._logTypeBox.TabIndex = 6;
			this._logTypeBox.SelectionChangeCommitted += new System.EventHandler(this.OnLogTypeChanged);
            // 
			// _logTypeLabel
			// 
			this._logTypeLabel.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this._logTypeLabel.Location = new System.Drawing.Point(8, 152);
			this._logTypeLabel.Name = "_logTypeLabel";
			this._logTypeLabel.RightToLeft = System.Windows.Forms.RightToLeft.No;
			this._logTypeLabel.Size = new System.Drawing.Size(80, 16);
			this._logTypeLabel.TabIndex = 5;
			this._logTypeLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// SSHShortcutLoginDialog
			// 
			this.AcceptButton = this._loginButton;
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 12);
			this.CancelButton = this._cancelButton;
			this.ClientSize = new System.Drawing.Size(298, 239);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this._logTypeBox,
																		  this._logTypeLabel,
																		  this._logFileBox,
																		  this._logFileLabel,
																		  this._selectlogButton,
																		  this._hostLabel,
																		  this._hostBox,
																		  this._methodLabel,
																		  this._methodBox,
																		  this._accountLabel,
																		  this._accountBox,
																		  this._authenticationTypeLabel,
																		  this._authenticationTypeBox,
																		  this._encodingLabel,
																		  this._encodingBox,
																		  this._privateKeyBox,
																		  this._privateKeyLabel,
																		  this._passphraseBox,
																		  this._passphraseLabel,
																		  this._privateKeySelect});
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
			this.MaximizeBox = false;
			this.MinimizeBox = false;
			this.Name = "SSHShortcutLoginDialog";
			this.ShowInTaskbar = false;
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
			this.ResumeLayout(false);

		}
		#endregion

		private void InitUI() {
            ITCPParameter tcp = (ITCPParameter)_sshParam.GetAdapter(typeof(ITCPParameter));
			_hostBox.Text = tcp.Destination;
			_methodBox.Text = _sshParam.Method.ToString();
			//if(_sshParam.Port!=22) _methodBox.Text += String.Format(TEnv.Strings.GetString("Caption.SSHShortcutLoginDialog.NotStandardPort"), _sshParam.Port);
			_accountBox.Text = _sshParam.Account;
            _authenticationTypeBox.Text = _sshParam.AuthenticationType.ToString(); //���ڂ�
			_encodingBox.Text = EnumDescAttribute.For(typeof(EncodingType)).GetDescription(this.TerminalSettings.Encoding);
            _logTypeBox.SelectedIndex =0;

			if(_sshParam.AuthenticationType==AuthenticationType.Password) {
				_privateKeyBox.Enabled = false;
				_privateKeySelect.Enabled = false;
			}
			else if(_sshParam.AuthenticationType==AuthenticationType.PublicKey) {
				_privateKeyBox.Text = _sshParam.IdentityFileName;
			}
			else if(_sshParam.AuthenticationType==AuthenticationType.KeyboardInteractive) {
				_privateKeyBox.Enabled = false;
				_privateKeySelect.Enabled = false;
				_passphraseBox.Enabled = false;
			}

			_passphraseBox.Text = "";
            if(_sshParam.PasswordOrPassphrase.Length==0 && TerminalSessionsPlugin.Instance.ProtocolService.ProtocolOptions.RetainsPassphrase) {
                string p = TerminalSessionsPlugin.Instance.ProtocolService.PassphraseCache.GetOrEmpty(tcp.Destination, _sshParam.Account);
                _passphraseBox.Text = p;
            }

			AdjustUI();
		}
		private void AdjustUI() {
			_passphraseBox.Enabled = _sshParam.AuthenticationType!=AuthenticationType.KeyboardInteractive;

			bool e = _logTypeBox.SelectedIndex!=(int)LogType.None;
			_logFileBox.Enabled = e;
			_selectlogButton.Enabled = e;
		}

		//���͓��e�Ɍ�肪����΂�����x������null��Ԃ��B�Ȃ���ΕK�v�ȂƂ���𖄂߂�TCPTerminalParam��Ԃ�
		private ISSHLoginParameter ValidateContent() {
			ISSHLoginParameter p = (ISSHLoginParameter)_sshParam.Clone();
			string msg = null;

			try {
                LogType logtype = (LogType)EnumDescAttribute.For(typeof(LogType)).FromDescription(_logTypeBox.Text, LogType.None);
                ISimpleLogSettings logsettings = null;
                if(logtype!=LogType.None) {
                    logsettings = CreateSimpleLogSettings(logtype, _logFileBox.Text);
                    if(logsettings==null) return null; //����L�����Z��
                }

				ITerminalSettings settings = this.TerminalSettings;

				if (logsettings != null) {
					settings.BeginUpdate();
					settings.LogSettings.Add(logsettings);
					settings.EndUpdate();
                }

                ITerminalParameter param = (ITerminalParameter)p.GetAdapter(typeof(ITerminalParameter));
				param.SetTerminalName(ToTerminalName(settings.TerminalType));
                
				if(p.AuthenticationType==AuthenticationType.PublicKey) {
					if(!File.Exists(_privateKeyBox.Text))
						msg = TEnv.Strings.GetString("Message.SSHShortcutLoginDialog.KeyFileNotExist");
					else
						p.IdentityFileName = _privateKeyBox.Text;
				}

                p.PasswordOrPassphrase = _passphraseBox.Text;

				if(msg!=null) {
					GUtil.Warning(this, msg);
					return null;
				}
				else
					return p;
			}
			catch(Exception ex) {
				GUtil.Warning(this, ex.Message);
				return null;
			}
		}
		private void OnOpenPrivateKey(object sender, System.EventArgs e) {
			string fn = TerminalUtil.SelectPrivateKeyFileByDialog(this);
			if(fn!=null) _privateKeyBox.Text = fn;
		}
        private void OnLogTypeChanged(object sender, System.EventArgs args) {
			AdjustUI();
		}

        protected override ITerminalParameter PrepareTerminalParameter() {
            _sshParam = ValidateContent();

            return _sshParam==null? null : (ITerminalParameter)_sshParam.GetAdapter(typeof(ITerminalParameter));
        }
        protected override void StartConnection() {
            IProtocolService protocolservice = TerminalSessionsPlugin.Instance.ProtocolService;
            _connector = protocolservice.AsyncSSHConnect(this, _sshParam);

            if(_connector==null) ClearConnectingState();
        }
        protected override void ShowError(string msg) {
            GUtil.Warning(this, msg, TEnv.Strings.GetString("Caption.LoginDialog.ConnectionError"));
        }
        private void SelectLog(object sender, System.EventArgs e) {
            string fn = LogUtil.SelectLogFileByDialog(this);
            if(fn!=null) _logFileBox.Text = fn;
        }

        private int ToAuthenticationIndex(AuthenticationType at) {
            if(at==AuthenticationType.Password)
                return 0;
            else if(at==AuthenticationType.PublicKey)
                return 1;
            else //if(at==AuthenticationType.KeyboardInteractive)
                return 2;
        }
    }
}
