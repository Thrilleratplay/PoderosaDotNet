/*
 * Copyright 2004,2006 The Poderosa Project.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 *
 * $Id: SerialConnection.cs,v 1.2 2010/12/24 22:46:48 kzmi Exp $
 */
using System;
using System.Collections.Generic;
using System.Text;
using System.Runtime.InteropServices;
using System.Threading;
using System.IO;
using System.Diagnostics;
using System.Windows.Forms;

using Poderosa.Sessions;
using Poderosa.Terminal;
using Poderosa.Forms;
using Poderosa.Util;
using Poderosa.Protocols;

namespace Poderosa.SerialPort
{

    internal class Win32Serial {
		[DllImport("kernel32.dll")]
		public static extern bool GetCommState(IntPtr handle, ref DCB dcb);
		[DllImport("kernel32.dll")]
		public static extern bool SetCommState(IntPtr handle, ref DCB dcb);
		[DllImport("kernel32.dll")]
		public static extern bool GetCommTimeouts(IntPtr handle, ref COMMTIMEOUTS timeouts);
		[DllImport("kernel32.dll")]
		public static extern bool SetCommTimeouts(IntPtr handle, ref COMMTIMEOUTS timeouts);
		[DllImport("kernel32.dll")]
		public static extern bool SetCommBreak(IntPtr handle);
		[DllImport("kernel32.dll")]
		public static extern bool ClearCommBreak(IntPtr handle);
		[DllImport("kernel32.dll")]
		public static extern bool WaitCommEvent(
			IntPtr hFile,                // handle to comm device
			out int lpEvtMask,           // event type
			ref OVERLAPPED lpOverlapped   // overlapped structure
			);
		[DllImport("kernel32.dll")]
		public static extern bool ClearCommError(
			IntPtr hFile,     // handle to communications device
			out int lpErrors, // error codes
			IntPtr lpStat  // communications status (�{����CommStat)
			);
		[DllImport("kernel32.dll")]
		public static extern bool SetCommMask(
			IntPtr hFile,                // handle to comm device
			int flags
			);

		[DllImport("kernel32.dll", CharSet=CharSet.Auto)]
		public static extern IntPtr CreateFile(
			string filename,
			uint dwDesiredAccess,                      // access mode
			uint dwShareMode,                          // share mode
			IntPtr lpSecurityAttributes, // SD
			uint dwCreationDisposition,                // how to create
			uint dwFlagsAndAttributes,                 // file attributes
			IntPtr hTemplateFile                        // handle to template file
			);

		[DllImport("kernel32.dll")]
		public static extern bool ReadFile(
			IntPtr hFile,                // handle to file
			byte[] lpBuffer,             // data buffer
			int nNumberOfBytesToRead,  // number of bytes to read
			ref int lpNumberOfBytesRead, // number of bytes read
			ref OVERLAPPED lpOverlapped    // overlapped buffer
			);
		[DllImport("kernel32.dll")]
		public static extern bool WriteFile(
			IntPtr hFile,                // handle to file
			byte[] lpBuffer,             // data buffer
			int nNumberOfBytesToRead,  // number of bytes to read
			ref int lpNumberOfBytesRead, // number of bytes read
			ref OVERLAPPED lpOverlapped    // overlapped buffer
			);
		[DllImport("kernel32.dll")]
		public static extern bool GetOverlappedResult(
			IntPtr hFile,                       // handle to file, pipe, or device
			ref OVERLAPPED lpOverlapped,          // overlapped structure
			ref int lpNumberOfBytesTransferred, // bytes transferred
			bool bWait                          // wait option
			);

        /// <summary>
        /// 
        /// </summary>
        /// <exclude/>
		[StructLayout(LayoutKind.Sequential)]
		public struct DCB { 
			public uint DCBlength; 
			public uint BaudRate;
			public uint Misc;
			/*
			DWORD fBinary: 1; 
			DWORD fParity: 1; 
			DWORD fOutxCtsFlow:1; 
			DWORD fOutxDsrFlow:1; 
			DWORD fDtrControl:2; 
			DWORD fDsrSensitivity:1; 
			DWORD fTXContinueOnXoff:1; 
			DWORD fOutX: 1; 
			DWORD fInX: 1; 
			DWORD fErrorChar: 1; 
			DWORD fNull: 1; 
			DWORD fRtsControl:2; 
			DWORD fAbortOnError:1; 
			DWORD fDummy2:17; 
			*/
			public ushort wReserved; 
			public ushort XonLim; 
			public ushort XoffLim; 
			public byte ByteSize; 
			public byte Parity; 
			public byte StopBits; 
			public byte XonChar; 
			public byte XoffChar; 
			public byte ErrorChar; 
			public byte EofChar; 
			public byte EvtChar; 
			public ushort wReserved1; 
		} 
        /// <summary>
        /// 
        /// </summary>
        /// <exclude/>
		[StructLayout(LayoutKind.Sequential)]
		public struct OVERLAPPED { 
			public int  Internal; 
			public int  InternalHigh; 
			public int  Offset; 
			public int  OffsetHigh; 
			public IntPtr hEvent; 
		}
        /// <summary>
        /// 
        /// </summary>
        /// <exclude/>
		[StructLayout(LayoutKind.Sequential)]
		public struct COMMTIMEOUTS {  
			public uint ReadIntervalTimeout; 
			public uint ReadTotalTimeoutMultiplier; 
			public uint ReadTotalTimeoutConstant; 
			public uint WriteTotalTimeoutMultiplier; 
			public uint WriteTotalTimeoutConstant; 
		}
    }


    internal class SerialTerminalOutput : ITerminalOutput {
        private IntPtr _fileHandle;

        public SerialTerminalOutput(IntPtr filehandle) {
            _fileHandle = filehandle;
        }

		public void SendBreak() {
			Win32Serial.SetCommBreak(_fileHandle);
			System.Threading.Thread.Sleep(500); //500ms�ҋ@
			Win32Serial.ClearCommBreak(_fileHandle);
		}

        public void SendKeepAliveData() {
        }

        public void AreYouThere() {
        }

        public void Resize(int width, int height) {
        }
    }

    internal class SerialSocket : IPoderosaSocket {
        private SerialTerminalConnection _parent;
        private IntPtr _fileHandle;
		private IByteAsyncInputStream _callback;
        private ByteDataFragment _dataFragment;
		private Win32Serial.OVERLAPPED _readOL;
		private Win32Serial.OVERLAPPED _writeOL;
        private SerialTerminalSettings _serialSettings;

        public SerialSocket(SerialTerminalConnection parent, IntPtr filehandle, SerialTerminalSettings settings) {
            _parent = parent;
            _serialSettings = settings;
            _fileHandle = filehandle;
 			_readOL.hEvent  = Win32.CreateEvent(IntPtr.Zero, 0, 0, null);
			_writeOL.hEvent = Win32.CreateEvent(IntPtr.Zero, 0, 0, null);

       }

        public bool Available {
            get {
                return false;
            }
        }
        public void Close() {
            Win32.CloseHandle(_readOL.hEvent);
			Win32.CloseHandle(_writeOL.hEvent);
		}
        public void ForceDisposed() {
            Win32.CloseHandle(_readOL.hEvent);
            Win32.CloseHandle(_writeOL.hEvent);
        }


		public void RepeatAsyncRead(IByteAsyncInputStream cb) {
			if(_callback!=null) throw new InvalidOperationException("duplicated AsyncRead() is attempted");
			
			_callback = cb;
            _dataFragment = new ByteDataFragment();
			new Thread(new ThreadStart(AsyncEntry)).Start();
			//_stream.BeginRead(_buf, 0, _buf.Length, new AsyncCallback(RepeatCallback), null);
		}

		private void AsyncEntry() {
			Win32Serial.OVERLAPPED ol = new Win32Serial.OVERLAPPED();
			try {
				//������
				bool success = false;
				int len = 0, flags = 0;
				ol.hEvent = Win32.CreateEvent(IntPtr.Zero, 0, 0, null);
				success = Win32Serial.ClearCommError(_fileHandle, out flags, IntPtr.Zero);
				//����SetCommMask�����s���Ȃ���WaitCommEvent�����s���Ă��܂�
				success = Win32Serial.SetCommMask(_fileHandle, 0);
				success = Win32Serial.SetCommMask(_fileHandle, 1); //EV_RXCHAR

				byte[] buf = new byte[128];
				while(true) {
					success = Win32Serial.WaitCommEvent(_fileHandle, out flags, ref ol); //�����͕���false���Ԃ�
					if(!success && Win32.GetLastError()!=Win32.ERROR_IO_PENDING)
						throw new Exception("WaitCommEvent failed " + Win32.GetLastError());

					//�����Ńf�[�^������܂Ńu���b�N����B�����A�h�L�������g�ɂ���WaitCommEvent�ɑΉ�����GetOverlappedResult��len�̒l�͖��Ӗ��Ƃ̂���
					success = Win32Serial.GetOverlappedResult(_fileHandle, ref ol, ref len, true);
					if(!success) break; //���Ƃ��ΐڑ���؂�Ȃǂ�false���Ԃ��Ă���

					do {
						len = 0;
						success = Win32Serial.ReadFile(_fileHandle, buf, buf.Length, ref len, ref _readOL);
						//����WaitForSingleObject���K�v���ǂ������悭�킩��Ȃ�
						//if(Win32.WaitForSingleObject(_readOL.hEvent, 5000)!=Win32.WAIT_OBJECT_0)
						//	throw new Exception("WaitForSingleObject timed out");
						success = Win32Serial.GetOverlappedResult(_fileHandle, ref _readOL, ref len, true);
                        _dataFragment.Set(buf, 0, len);
						if(len>0) _callback.OnReception(_dataFragment);
					} while(len > 0);
				}
			}
			catch(Exception ex) {
				if(!_parent.IsClosed) {
					_callback.OnAbnormalTermination(ex.Message);
				}
			}
			finally {
				Win32.CloseHandle(ol.hEvent);
				//Debug.WriteLine("COM thread terminating...");
			}
		}

        public void Transmit(ByteDataFragment data) {
            Transmit(data.Buffer, data.Offset, data.Length);
        }

        public void Transmit(byte[] data, int offset, int length) {
            byte nl = (byte)(_serialSettings.TransmitNL==Poderosa.ConnectionParam.NewLine.CR? 13 : 10);
           
            if(_serialSettings.TransmitDelayPerChar==0) {
                if(_serialSettings.TransmitDelayPerLine==0)
					WriteMain(data, offset, length); //�ł��P��
				else { //���s�̂݃E�F�C�g�}��
					int limit = offset+length;
					int c = offset;
					while(offset<limit) {
						if(data[offset]==nl) {
							WriteMain(data, c, offset-c+1);
                            Thread.Sleep(_serialSettings.TransmitDelayPerLine);
							c = offset+1;
						}
						offset++;
					}
					if(c < limit) WriteMain(data, c, limit-c);
				}
			}
			else {
            	for(int i=0; i<length; i++) {
					WriteMain(data, offset+i, 1);
                    Thread.Sleep(data[offset+i]==nl? _serialSettings.TransmitDelayPerLine : _serialSettings.TransmitDelayPerChar);
				}
			}

		}

		private void WriteMain(byte[] buf, int offset, int length) {
			if(length==0) return; //�����O���� fixed(byte* p = buf) �����s���Ă��܂�
			
			int result = 0;
			if(offset!=0) {
				byte[] nb = new byte[length];
				Array.Copy(buf, offset, nb, 0, length);
				buf = nb; //����WriteFile��offset���O�łȂ��Ƃ��͂����ɂ̓T�|�[�g�ł��Ȃ�
			}
			bool success;
			success = Win32Serial.WriteFile(_fileHandle, buf, length, ref result, ref _writeOL);
			if(Win32.GetLastError()!=Win32.ERROR_IO_PENDING)
				throw new IOException("WriteFile failed for " + Win32.GetLastError());
			//����WaitForSingleObject���K�v���ǂ������悭�킩��Ȃ�
			//err = Win32.WaitForSingleObject(_writeOL.hEvent, 10000);
			success = Win32Serial.GetOverlappedResult(_fileHandle, ref _writeOL, ref result, true);
			Debug.Assert(success);
		}

    }

    /*
     * �m�[�g�@�Ȃ��V���A���ʐM������Ȃ��ƂɂȂ��Ă��邩
     * 
     * �@�V���A���ʐM������Ȃɑ�ςȂ̂́A���Ƃ���������Windows�̐݌v�������ł���B
     * �@���ʂł���΁AReadFile�Ŕ񓯊��ǂݎ������݂āA���ꂩ��WaitForSingleObject���ĂԂ̂����A
     * �V���A���̏ꍇ�͂����ő����߂��Ă��܂��B�]���āA.NET Framework�̋����Ƃ��Ă�BeginRead�̒���
     * �ɃR�[���o�b�N���Ă΂�Ă��܂��A������r�W�[���[�v�ɂȂ�̂ł���B
     * �@�����Ƃ����񓯊��ʐM�����邽�߂ɂ́AWaitCommEvent���g��Ȃ��Ă͂Ȃ�Ȃ��̂ŁA.NET Framework
     * �̃T�|�[�g�O�ɂȂ��Ă��܂��B
     * 
    */

    internal class SerialTerminalConnection : ITerminalConnection {
        //�V���A���̔񓯊��ʐM�������Ƃ�낤�Ƃ����.NET���C�u�����ł͕s�\���Ȃ̂łق�API���ǂ�
        private IntPtr _fileHandle;
        private SerialSocket _serialSocket;
        private SerialTerminalOutput _serialTerminalOutput;
        private SerialTerminalParam _serialTerminalParam;
        private bool _closed;

        public SerialTerminalConnection(SerialTerminalParam p, SerialTerminalSettings settings, IntPtr fh) {
            _serialTerminalParam = p;
            _fileHandle = fh;
            _serialSocket = new SerialSocket(this, fh, settings);
            _serialTerminalOutput = new SerialTerminalOutput(fh);
            //_socket = _serialSocket;
            //_terminalOutput = _serialTerminalOutput;
        }
        public void Close() {
            if(_closed) return; //�Q�x�ȏ�N���[�Y���Ă�����p�Ȃ� 

            _closed = true;
            _serialSocket.Close();
            Win32.CloseHandle(_fileHandle);
            _fileHandle = IntPtr.Zero;
            //Debug.WriteLine("COM connection termingating...");
        }
    


		public void ApplySerialParam(SerialTerminalSettings settings) {
			//param�̓��e��DCB���X�V���ăZ�b�g���Ȃ���
			Win32Serial.DCB dcb = new Win32Serial.DCB();
			SerialPortUtil.FillDCB(_fileHandle, ref dcb);
			SerialPortUtil.UpdateDCB(ref dcb, settings);

			if(!Win32Serial.SetCommState(_fileHandle, ref dcb))
				throw new ArgumentException(SerialPortPlugin.Instance.Strings.GetString("Message.SerialTerminalConnection.ConfigError"));
		}

        public ITerminalParameter Destination {
            get {
                return _serialTerminalParam;
            }
        }

        public ITerminalOutput TerminalOutput {
            get {
                return _serialTerminalOutput;
            }
        }

        public IPoderosaSocket Socket {
            get {
                return _serialSocket;
            }
        }

        public bool IsClosed {
            get {
                return _closed;
            }
        }

        public IAdaptable GetAdapter(Type adapter) {
            return SerialPortPlugin.Instance.PoderosaWorld.AdapterManager.GetAdapter(this, adapter);
        }
    }

    internal class SerialConnectionFactory : ITerminalConnectionFactory {
        public bool IsSupporting(ITerminalParameter param, ITerminalSettings settings) {
            SerialTerminalParam sp = param as SerialTerminalParam;
            SerialTerminalSettings ts = settings as SerialTerminalSettings;
            return sp!=null && ts!=null;
        }

        public ITerminalConnection EstablishConnection(IPoderosaMainWindow window, ITerminalParameter param, ITerminalSettings settings) {
            SerialTerminalParam sp = param as SerialTerminalParam;
            SerialTerminalSettings ts = settings as SerialTerminalSettings;
            Debug.Assert(sp!=null && ts!=null);

            return SerialPortUtil.CreateNewSerialConnection(window, sp, ts);
        }
    }

    internal class SerialPortUtil {
        public static SerialTerminalConnection CreateNewSerialConnection(IPoderosaMainWindow window, SerialTerminalParam param, SerialTerminalSettings settings) {
            bool successful = false;
            FileStream strm = null;
            try {
                StringResource sr = SerialPortPlugin.Instance.Strings;
                //Debug.WriteLine("OPENING COM"+param.Port);
                string portstr = String.Format("\\\\.\\COM{0}", param.Port);
                IntPtr ptr = Win32Serial.CreateFile(portstr, Win32.GENERIC_READ|Win32.GENERIC_WRITE, 0, IntPtr.Zero, Win32.OPEN_EXISTING, Win32.FILE_ATTRIBUTE_NORMAL|Win32.FILE_FLAG_OVERLAPPED, IntPtr.Zero);
                if(ptr==Win32.INVALID_HANDLE_VALUE) {
                    string msg = sr.GetString("Message.FailedToOpenSerial");
                    int err = Win32.GetLastError();
                    if(err==2) msg += sr.GetString("Message.NoSuchDevice");
                    else if(err==5) msg += sr.GetString("Message.DeviceIsBusy");
                    else msg += "\nGetLastError="+ Win32.GetLastError();
                    throw new Exception(msg);
                }
                //strm = new FileStream(ptr, FileAccess.Write, true, 8, true);
                Win32Serial.DCB dcb = new Win32Serial.DCB();
                FillDCB(ptr, ref dcb);
                UpdateDCB(ref dcb, settings);

                if(!Win32Serial.SetCommState(ptr, ref dcb))
                    throw new Exception(sr.GetString("Message.FailedToConfigSerial"));
                Win32Serial.COMMTIMEOUTS timeouts = new Win32Serial.COMMTIMEOUTS();
                Win32Serial.GetCommTimeouts(ptr, ref timeouts);
                timeouts.ReadIntervalTimeout = 0xFFFFFFFF;
                timeouts.ReadTotalTimeoutConstant = 0;
                timeouts.ReadTotalTimeoutMultiplier = 0;
                timeouts.WriteTotalTimeoutConstant = 100;
                timeouts.WriteTotalTimeoutMultiplier = 100;
                Win32Serial.SetCommTimeouts(ptr, ref timeouts);
                successful = true;
                SerialTerminalConnection r = new SerialTerminalConnection(param, settings, ptr);
                return r;
            }
            catch(Exception ex) {
                RuntimeUtil.SilentReportException(ex);
                if(window!=null)
                    window.Warning(ex.Message);
                else
                    GUtil.Warning(Form.ActiveForm, ex.Message); //TODO �ꂵ�������BIPoderosaForm�����������x�[�X�N���X��Core�ɂł������Ă����ق��������̂�
                return null;
            }
            finally {
                if(!successful && strm!=null) strm.Close();
            }
        }
        public static bool FillDCB(IntPtr handle, ref Win32Serial.DCB dcb) {
            dcb.DCBlength = (uint)System.Runtime.InteropServices.Marshal.SizeOf(typeof(Win32Serial.DCB)); //sizeof���炢unsafe�łȂ��Ă��g�킹�Ă����
            return Win32Serial.GetCommState(handle, ref dcb);
        }

        public static void UpdateDCB(ref Win32Serial.DCB dcb, SerialTerminalSettings param) {
            dcb.BaudRate = (uint)param.BaudRate;
            dcb.ByteSize = param.ByteSize;
            dcb.Parity = (byte)param.Parity;
            dcb.StopBits = (byte)param.StopBits;
            //�t���[����FTeraTerm�̃\�[�X���炿����ς��Ă���
            if(param.FlowControl==FlowControl.Xon_Xoff) {
                //dcb.fOutX = TRUE;
                //dcb.fInX = TRUE;
                //dcb�����S�ɃR���g���[������I�v�V�������K�v������
                dcb.Misc |= 0x300; //��L�Q�s�̂����
                dcb.XonLim = 2048; //CommXonLim;
                dcb.XoffLim = 2048; //CommXoffLim;
                dcb.XonChar = 0x11;
                dcb.XoffChar = 0x13;
            }
            else if(param.FlowControl==FlowControl.Hardware) {
                //dcb.fOutxCtsFlow = TRUE;
                //dcb.fRtsControl = RTS_CONTROL_HANDSHAKE;
                dcb.Misc |= 0x4 | 0x2000;
            }
        }

        public static SerialTerminalSettings CreateDefaultSerialTerminalSettings(int port) {
            SerialTerminalSettings ts = new SerialTerminalSettings();
            ts.BeginUpdate();
            ts.Icon = SerialPortIconList.LoadIcon(SerialPortIconList.ICON_SERIAL);
            ts.Caption = String.Format("COM{0}", port);
            ts.EndUpdate();
            return ts;
        }

        public static int GetMaxPort() {
            int max = 1;
            try {
                foreach(string t in System.IO.Ports.SerialPort.GetPortNames()) {
                    if (t.StartsWith("COM")) {
                        int port = Int32.Parse(t.Substring(3)); //"COM"����������
                        max = Math.Max(max, port);
                    }
                }
            }
            catch(Exception ex) {
                RuntimeUtil.ReportException(ex);
            }
            return max;
        }
    }
}
