/*
 * Copyright 2004,2006 The Poderosa Project.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 *
 * $Id: CommandResultPopup.cs,v 1.1 2010/11/19 15:41:11 kzmi Exp $
 */
using System;
using System.Collections.Generic;
using System.Text;
using System.Drawing;
using System.Windows.Forms;
using System.Diagnostics;

using Poderosa.Plugins;
using Poderosa.View;
using Poderosa.Forms;
using Poderosa.Document;
using Poderosa.Commands;

namespace Poderosa.Terminal {

    /// <summary>
    /// <ja>
    /// �V�F���փR�}���h���������s����N�_�ł��B
    /// </ja>
    /// <en>
    /// Starting point to the shell that executes the command automatically. 
    /// </en>
    /// </summary>
    /// <remarks>
    /// <ja>
    /// ���̃C���^�t�F�[�X�̉���́A�܂�����܂���B
    /// </ja>
    /// <en>
    /// It has not explained this interface yet. 
    /// </en>
    /// </remarks>
    public interface IShellCommandExecutor : IAdaptable {
        void StartCommandResultProcessor(ICommandResultProcessor processor, bool start_with_linebreak);
        void StartCommandResultProcessor(ICommandResultProcessor processor, string command_body, bool start_with_linebreak);
        bool IsPromptReady { get; }
    }


    //�R�}���h�̃x�[�X
    internal abstract class CommandResultProcessorBase : ICommandResultProcessor, ICommandResultProcessorMenuItem {
        protected string _textID;
        protected string _executingCommand;
        protected AbstractTerminal _terminal;

        public void StartCommand(AbstractTerminal terminal, string command_text, GLine prompt_line) {
            _executingCommand = command_text;
            _terminal = terminal;
        }
        public abstract void EndCommand(List<GLine> command_result);

        public IAdaptable GetAdapter(Type adapter) {
            return TerminalEmulatorPlugin.Instance.PoderosaWorld.AdapterManager.GetAdapter(this, adapter);
        }

        public string Text {
            get {
                return GEnv.Strings.GetString(_textID);
            }
        }
        public bool IsEnabled(AbstractTerminal control_host) {
            return true;
        }
        public ICommandResultProcessor CommandBody {
            get {
                return this;
            }
        }

        protected static void AsyncResultQuickHack(TerminalControl tc, IAsyncResult ar) {
            if(ar.AsyncWaitHandle.WaitOne(100, false)) //IntelliSense�Ɠ��l�̗��R�Ŏ��Ԑ�������Wait
                tc.EndInvoke(ar);
        }
    }

    //�R�}���h���ʂ�V�Z�b�V�����Ƃ��ă|�b�v�A�b�v
    internal class PopupCommandResult : CommandResultProcessorBase {
        public PopupCommandResult() {
            _textID = "Menu.PopupCommandResult";
        }
        public override void EndCommand(List<GLine> command_result) {
            CommandResultDocument doc = new CommandResultDocument(_executingCommand);
            foreach(GLine line in command_result)
                doc.AddLine(line.Clone());

            TerminalControl tc = _terminal.TerminalHost.TerminalControl;
            if(tc==null) return;

            Debug.Assert(tc.InvokeRequired);

            IAsyncResult ar = tc.BeginInvoke(CommandResultSession.Start, _terminal, doc);
            AsyncResultQuickHack(tc, ar);
        }
    }

    //�R�}���h���ʂ��N���b�v�{�[�h��
    internal class CopyCommandResult : CommandResultProcessorBase {
        public CopyCommandResult() {
            _textID = "Menu.CopyCommandResult";
        }

        public override void EndCommand(List<GLine> command_result) {
            StringBuilder bld = new StringBuilder();
            foreach(GLine line in command_result) {
                char[] text = line.Text;
                for(int i=0; i<text.Length; i++) {
                    char ch = text[i];
                    if(ch=='\0') break;
                    if(ch!=GLine.WIDECHAR_PAD) bld.Append(ch);
                }

                if(line.EOLType!=EOLType.Continue) bld.Append("\r\n");
            }

            if(bld.Length > 0) {
                //�R�s�[�̓��C���X���b�h�ł����
                TerminalControl tc = _terminal.TerminalHost.TerminalControl;
                if(tc==null) return;

                Debug.Assert(tc.InvokeRequired);
                IAsyncResult ar = tc.BeginInvoke(new CopyToClipboardDelegate(CopyToClipboard), bld.ToString());
                AsyncResultQuickHack(tc, ar);
            }
        }
        private delegate void CopyToClipboardDelegate(string data);
        private void CopyToClipboard(string data) {
            try {
                Clipboard.SetDataObject(data, false);
            }
            catch(Exception ex) {
                RuntimeUtil.ReportException(ex);
            }
        }
    }

    internal class CommandResultRecognizer : IPromptProcessor, IShellCommandExecutor {
        protected enum State {
            NotPrompt,
            Prompt, //�v�����v�g��t��
            Fetch   //�R�}���h�̌��ʂ���M��
        }
        protected AbstractTerminal _terminal;
        protected State _state;

        private GLine _lastPromptLine;
        protected string _lastCommand;

        private int _commandStartLineID;
        private ICommandResultProcessor _currentProcessor;

        public CommandResultRecognizer(AbstractTerminal terminal) {
            _terminal = terminal;
            _terminal.PromptRecognizer.AddListener(this);
            _state = State.NotPrompt;
        }

        public AbstractTerminal Terminal {
            get {
                return _terminal;
            }
        }

        #region IPromptRecognizer
        public void OnPromptLine(GLine line, string prompt, string command) {
            _lastPromptLine = line;
            _lastCommand = command;

            Debug.WriteLineIf(DebugOpt.CommandPopup, "OnPromptLine " + _state.ToString() +";"+ command);
            if(_currentProcessor!=null && _state==State.Fetch && command.Trim().Length==0) {
                ProcessCommandResult(line.ID-1);
                _state = State.Prompt;
            }
            else if(_state!=State.Fetch) 
                _state = State.Prompt;
        }

        public void OnNotPromptLine() {
            if(_state!=State.Fetch) _state = State.NotPrompt;
        }
        #endregion

        //�|�b�v�A�b�v�Ώۂ̍s���W�߂č\�z�B�����͎�M�X���b�h�ł̎��s�ł��邱�Ƃɒ���
        private void ProcessCommandResult(int end_line_id) {
            List<GLine> result = new List<GLine>();
            TerminalDocument doc = _terminal.GetDocument();
            GLine line = doc.FindLineOrNull(_commandStartLineID);
            while(line!=null && line.ID<=end_line_id) {
                //Debug.WriteLine("P]"+new string(line.Text, 0, line.DisplayLength));
                result.Add(line);
                line = line.NextLine;
            }

            //�����Ƃ�Ă�������s
            if(result.Count>0)
                _currentProcessor.EndCommand(result);
            else
                Debug.WriteLineIf(DebugOpt.CommandPopup, String.Format("Ignored for 0-length, start={0} end={1}", _commandStartLineID, end_line_id));

            _currentProcessor = null;
        }

        #region IShellCommandExecutor
        //�O����������s�\�ȃR�}���h�����|�C���g
        public void StartCommandResultProcessor(ICommandResultProcessor processor, bool start_with_linebreak) {
            StartCommandResultProcessor(processor, null, start_with_linebreak); //���s�݂̂ŃX�^�[�g
        }
        public void StartCommandResultProcessor(ICommandResultProcessor processor, string command_body, bool start_with_linebreak) {
            _currentProcessor = processor;
            _commandStartLineID = _lastPromptLine.ID+1;
            string command = _lastCommand;
            if(!String.IsNullOrEmpty(command_body)) {
                command += command_body;
                _terminal.TerminalHost.TerminalTransmission.SendString(command.ToCharArray());
            }

            _state = State.Fetch; //�R�}���h�{�̑��M�������_�Ŏ擾���J�n
            processor.StartCommand(_terminal, command, _lastPromptLine);
            //Enter�𑗐M���ăR�}���h���s�J�n
            if(start_with_linebreak)
                _terminal.TerminalHost.TerminalTransmission.SendLineBreak();
        }
        public bool IsPromptReady {
            get {
                return _state==State.Prompt;
            }
        }
        public IAdaptable GetAdapter(Type adapter) {
            return TerminalEmulatorPlugin.Instance.PoderosaWorld.AdapterManager.GetAdapter(this, adapter);
        }
        #endregion


    }

    //�v�����v�g�F�����āA�|�b�v�A�b�v������R�}���h���s������
    internal class PopupStyleCommandResultRecognizer : CommandResultRecognizer {

        public const string POPUP_MENU_EXTENSION_POINT = "org.poderosa.terminalemulator.commandProcessorPopupMenu";

        //ExtP�쐬�ƃf�t�H���g�̓o�^
        public static void CreateExtensionPointAndDefaultCommands(IPluginManager pm) {
            IExtensionPoint pt = pm.CreateExtensionPoint(POPUP_MENU_EXTENSION_POINT, typeof(ICommandResultProcessorMenuItem), TerminalEmulatorPlugin.Instance);
            pt.RegisterExtension(new PopupCommandResult());
            pt.RegisterExtension(new CopyCommandResult());
        }


        public PopupStyleCommandResultRecognizer(AbstractTerminal terminal) : base(terminal) {
        }

        //TerminalControl���痈����
        public bool ProcessKey(Keys modifiers, Keys keybody) {
            if(_state==State.Prompt && _lastCommand.Length>0 && TerminalEmulatorPlugin.Instance.TerminalEmulatorOptions.CommandPopupKey==(modifiers|keybody)) { 
                ShowMenu();
                return true;
            }

            return false;
        }

        private void ShowMenu() {
            TerminalControl tc = _terminal.TerminalHost.TerminalControl;
            Debug.Assert(tc!=null);
            TerminalDocument doc = _terminal.GetDocument();
            SizeF pitch = tc.GetRenderProfile().Pitch;
            Point popup = new Point((int)(doc.CaretColumn * pitch.Width), (int)((doc.CurrentLineNumber - doc.TopLineNumber + 1) * pitch.Height));

            IPoderosaForm f = tc.FindForm() as IPoderosaForm;
            Debug.Assert(f!=null);
            //EXTP�ɂ��Ă������񂾂���
            f.ShowContextMenu(new IPoderosaMenuGroup[] { new PoderosaMenuGroupImpl(CreatePopupMenuItems()) },
                (ICommandTarget)tc.GetAdapter(typeof(ICommandTarget)),
                tc.PointToScreen(popup),
                ContextMenuFlags.SelectFirstItem);
        }
        private IPoderosaMenu[] CreatePopupMenuItems() {
            List<IPoderosaMenu> result = new List<IPoderosaMenu>();
            foreach(ICommandResultProcessorMenuItem item in TerminalEmulatorPlugin.Instance.PoderosaWorld.PluginManager.FindExtensionPoint(POPUP_MENU_EXTENSION_POINT).GetExtensions()) {
                CommandAdapter ca = new CommandAdapter(this, item);
                result.Add(new PoderosaMenuItemImpl(
                    new PoderosaCommandImpl(new ExecuteDelegate(ca.Execute), new CanExecuteDelegate(ca.CanExecute)), item.Text));
            }
            return result.ToArray();
        }

        private class CommandAdapter {
            private PopupStyleCommandResultRecognizer _parent;
            private ICommandResultProcessorMenuItem _item;

            public CommandAdapter(PopupStyleCommandResultRecognizer parent, ICommandResultProcessorMenuItem proc) {
                _item = proc;
                _parent = parent;
            }
            public CommandResult Execute(ICommandTarget target) {
                _parent.StartCommandResultProcessor(_item.CommandBody, true);
                return CommandResult.Succeeded;
            }

            public bool CanExecute(ICommandTarget target) {
                return _item.IsEnabled(_parent.Terminal);
            }

        }


    }
}
