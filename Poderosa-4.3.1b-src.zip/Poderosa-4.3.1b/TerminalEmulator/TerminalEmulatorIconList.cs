/*
 * Copyright 2004,2006 The Poderosa Project.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 *
 * $Id: TerminalEmulatorIconList.cs,v 1.1 2010/11/19 15:41:11 kzmi Exp $
 */
using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace Poderosa.Terminal
{
	/// <summary>
	/// IconList �̊T�v�̐����ł��B
	/// </summary>
    /// <exclude/>
	public class TerminalEmulatorIconList : System.Windows.Forms.Form
	{
		System.Windows.Forms.ImageList _imageList;
		private System.ComponentModel.IContainer components;

		public TerminalEmulatorIconList()
		{
			//
			// Windows �t�H�[�� �f�U�C�i �T�|�[�g�ɕK�v�ł��B
			//
			InitializeComponent();

			//
			// TODO: InitializeComponent �Ăяo���̌�ɁA�R���X�g���N�^ �R�[�h��ǉ����Ă��������B
			//
		}

		/// <summary>
		/// �g�p����Ă��郊�\�[�X�Ɍ㏈�������s���܂��B
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows �t�H�[�� �f�U�C�i�Ő������ꂽ�R�[�h 
		/// <summary>
		/// �f�U�C�i �T�|�[�g�ɕK�v�ȃ��\�b�h�ł��B���̃��\�b�h�̓��e��
		/// �R�[�h �G�f�B�^�ŕύX���Ȃ��ł��������B
		/// </summary>
		private void InitializeComponent()
		{
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(TerminalEmulatorIconList));
            this._imageList = new System.Windows.Forms.ImageList(this.components);
            this.SuspendLayout();
            // 
            // _imageList
            // 
            this._imageList.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("_imageList.ImageStream")));
            this._imageList.TransparentColor = System.Drawing.Color.Transparent;
            this._imageList.Images.SetKeyName(0, "");
            this._imageList.Images.SetKeyName(1, "");
            this._imageList.Images.SetKeyName(2, "");
            this._imageList.Images.SetKeyName(3, "");
            this._imageList.Images.SetKeyName(4, "");
            this._imageList.Images.SetKeyName(5, "");
            this._imageList.Images.SetKeyName(6, "intellisense.ico");
            this._imageList.Images.SetKeyName(7, "poderosa.ico");
            // 
            // TerminalEmulatorIconList
            // 
            this.AutoScaleBaseSize = new System.Drawing.Size(5, 12);
            this.ClientSize = new System.Drawing.Size(292, 266);
            this.Name = "TerminalEmulatorIconList";
            this.Text = "IconList";
            this.ResumeLayout(false);

		}
		#endregion

        private static TerminalEmulatorIconList _iconList;

		public const int ICON_LOCALECHO = 0;
        public const int ICON_LINEFEED = 1;
		public const int ICON_SUSPENDLOG = 2;
		public const int ICON_COMMENTLOG = 3;
		public const int ICON_INFO = 4;
		public const int ICON_BELL = 5;
        public const int ICON_INTELLISENSE = 6;
        public const int ICON_PODEROSA = 7;
		
		public static Image LoadIcon(int id) {
			if(_iconList==null)
                _iconList = new TerminalEmulatorIconList();
			return _iconList._imageList.Images[id];
		}

	}
}
